#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int main(int argc, char*argv[])
{
  FILE *fptr;
  FILE *wptr;
  BMP_Image* bmpptr;
  BMP_Image* bmpNEW;
  
  if (argc != 3){
    fprintf(stderr, "Wrong number of arguments\n");
    return EXIT_FAILURE;
  }
  fptr = fopen(argv[argc - 2], "r");
  if(fptr == NULL){
    fprintf(stderr, "Can't open input file\n");
    return EXIT_FAILURE;
  }
  
  // read image into structure
  bmpptr = Read_BMP_Image(fptr);
  if(bmpptr == NULL){
    fprintf(stderr, "Error reading input file\n");
    return EXIT_FAILURE;
  }
  fclose(fptr);
  
  // starting converting 24 to 16 or 24 to 16
  int bytesPerRow =  bmpptr->header.bits / 8;

  if(bytesPerRow == 3){
    bmpNEW = Convert_24_to_16_BMP_Image(bmpptr);
  }else if(bytesPerRow == 2){
    bmpNEW = Convert_16_to_24_BMP_Image(bmpptr);
  }else{
    fprintf(stderr, "Can't convert the image\n");
    return EXIT_FAILURE;
  }
  
  // write into file 
  wptr = fopen(argv[argc - 1], "w");
  if(wptr == NULL){
    fprintf(stderr, "Can't open file for output\n");
    return EXIT_FAILURE;
    }

  Write_BMP_Image(wptr, bmpNEW);
  fclose(wptr);
  
  return EXIT_SUCCESS;
  
}
