#include <stdio.h>
#include <stdlib.h>
#include "answer07.h"

/* Determine the dimensions of the maze contain in file. */
/* The maze will always be of the correct format */
/* the number of rows is to be stored at location pointed to by nrow */ 
/* the number of ncol is to be stored at location pointed to by ncol */

void Find_maze_dimensions(FILE *fptr, int *nrow, int *ncol)
{
    *nrow = *ncol = 0;
    int row = 0;
    int col = 0;
    char ch;
    long int i;
    long int j;
    
    fseek(fptr, 0, SEEK_SET);

    
    for (col = 0; ch != '\n'; col++)
    {
        ch = fgetc(fptr);
    }
    
    fseek(fptr, 0, SEEK_END);
    j = ftell(fptr);
    
    fseek(fptr, 0, SEEK_SET);
    for (i = 0; i < j; i++)
    {
        ch = fgetc(fptr);
        if(ch == '\n')
        {
            row++;
        }
    }
    
    *nrow = row;
    *ncol = col - 1;
}

/* Determine the column location of the top opening */
/* you may assume that the maze is of the correct format */

int Find_opening_location(FILE *fptr)
{
  int numOpen = 0;
  int j;
  char ch ;

  fseek(fptr, 0, SEEK_END);
  j = ftell(fptr);
  
  fseek(fptr, 0, SEEK_SET);
  ch = fgetc(fptr);
  for(numOpen = 0; ch != ' '; numOpen++)
  {
      ch = fgetc(fptr); 
  }

   return numOpen;
}

/* Count the number of locations that are PATH */
/* A location is PATH if it is a space, ' ', or PATH */
/* you may assukme that the maze is of the correct format */

int Count_path_locations(FILE *fptr)
{  
   int numPathf = 0;
   int j;
   char ch;
   int i;

   fseek(fptr, 0, SEEK_END);
   j = ftell(fptr);
  
   fseek(fptr, 0, SEEK_SET);
   
   for(i = 0; i < j; i++)
   {
     ch = fgetc(fptr);
     if(ch == ' ')
     {
       numPathf++;
     } 
   }
   
   return numPathf;
}

/* Return the type of location: WALL or PATH */
/* The location is specified by its row-column coordinates. */
/* The coordinates are specified by row and col */
/* you may assume that these coordinates are always valid */
/* you may assume that the maze is of the correct format */

char Get_location_type(FILE *fptr, int row, int col) 
{
  char type;
  int nr;
  int nc;
  int i;
  
  Find_maze_dimensions(fptr, &nr, &nc);
  i = nc * row + col + row; 
  fseek(fptr, i, SEEK_SET);
  
  type = fgetc(fptr);
 
  return type;
}

/* Given a filename, re-represent the maze in the file pointer fptr */
/* in a single line */
/* The return value should be the number of characters written into the */
/* the new file */
/* if the writing to a file fails, you should return -1 */ 
/* you may assume that the maze is of the correct format */

int Represent_maze_in_one_line(char *filename, FILE *fptr)
{
  int i;
  int j;
  FILE *wptr; 
  char ch;
  int numChar; 
  wptr = fopen(filename, "w");
  if(wptr == NULL)
  {
    return -1;
  }
  fseek(fptr, 0, SEEK_END);
  j = ftell(fptr);
  
  fseek(fptr, 0, SEEK_SET);
  fseek(wptr, 0, SEEK_SET);
  for (i = 0; i < j; i++)
  {
    ch = fgetc(fptr);
    
    if (ch != '\n')
    {
      fputc(ch, wptr);
      if(ch == EOF)
      {
	return -1;
      }
    }
  } 
  
  fseek(wptr, 0, SEEK_END);
  numChar = ftell(wptr);
	fclose(wptr);  
  return numChar;
}
