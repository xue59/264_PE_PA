//  pe07.c
#include <stdio.h>
#include <stdlib.h>
#include "answer07.h"


int main(int argc, char ** argv)
{
    FILE *ptr;
    int numRow;
    int numCol;
    int opening;
    int numPath;
    int r = 0;
    int c = 0;
    char locType;
    int numChara;

    ptr = fopen(argv[1], "r+");
    
    Find_maze_dimensions(ptr, &numRow, &numCol);
    printf("Row: %d Col: %d", numRow, numCol);
    
    opening = Find_opening_location(ptr);
    printf("\nOpening: col %d ", opening);
    
    numPath = Count_path_locations(ptr);
    printf("\nNumber pathes: %d", numPath);
    
    locType = Get_location_type(ptr, r, c);
    printf("\nType: %c", locType);
    
    numChara = Represent_maze_in_one_line(argv[2], ptr);
    printf("\nNumber characters: %d", numChara);
	
	fclose(ptr);
    return EXIT_SUCCESS;
}
