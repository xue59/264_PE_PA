#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "answer10.h"

int main(int argc, char*argv[])
{	
  lnode *tree;
  creat_count_file(argv[1], argv[2]);
  creat_sort_file(argv[1], argv[3]);
  creat_huffman_file(argv[1], argv[4], &tree);
  return 0;
}
