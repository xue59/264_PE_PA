#include <stdio.h>
#include <stdlib.h>
#include "answer10.h"

/* ====================================PE10=========================================*/
void preorder(tnode *root);
void printlnode(lnode *lnodePtr);
lnode *PQ_enqueue(lnode **pq, const void* new_object,  int (*int_cmp)(const void*, const void*));
static int int_cmp(const void *p1, const void *p2);
tnode *bst_construct(int *array, int lb, int ub);
lnode *stack_pop(lnode **stack);
void encoding_fn(tnode *tree, char path[], int index,  FILE* fwptr);
void lnode_destroy(lnode *list, void (*destroy_fn)(void *));
void destroy_fnf(void * varf);
void bst_destroy(tnode *root);

void creat_count_file(char* filename, char *outputFile)
{
  int array[256] = {0};
  FILE* fptr;
  FILE* wptr;
  int numChars;
  int i;
  char ch;
  int intChar;
  
  fptr = fopen(filename, "r");
  if(fptr == NULL){
    return ;
  }
  wptr = fopen(outputFile, "w");
  if(wptr == NULL){
    return ;
  }
  
  fseek(fptr, 0, SEEK_END);
  numChars = ftell(fptr);
  
  fseek(fptr, 0, SEEK_SET);
  
  for(i = 0; i < numChars; i++){
    ch = fgetc(fptr);
    intChar = (int)ch;
    
    array[intChar] = array[intChar] + 1; 
  }    
  
  fseek(wptr, 0, SEEK_SET);
  for(i = 0; i <= 255; i++)
  {
    fprintf(wptr, "%d", array[i]);
    fputc('\n', wptr);
  }
  
  fclose(fptr);
  fclose(wptr);
  return;
}
void creat_sort_file(char* filename, char* outputFile)
{
  int array[256] = {0};
  FILE* fptr;
  FILE* wptr;
  int numChars;
  int i;
  int j;
  char ch;
  int intChar;
  char charDis;
    
  fptr = fopen(filename, "r");    
  if(fptr == NULL){
    return ;
  }
  wptr = fopen(outputFile, "w");  
  if(wptr == NULL){
    return ;
  }
  fseek(fptr, 0, SEEK_END);
  numChars = ftell(fptr);
  
  fseek(fptr, 0, SEEK_SET);
  
  for(i = 0; i < numChars; i++){
    ch = fgetc(fptr);
    intChar = (int)ch;
    
    array[intChar] = array[intChar] + 1; 
  }
  //=================================================================================================
  fseek(wptr,0,SEEK_SET);
  for(i = 1; i <= numChars; i++){
    for(j = 0; j <= 255; j++){
      if(array[j] == i){
	charDis = (char)j;
	fputc(charDis, wptr);
	fputc(':', wptr);
	fprintf(wptr, "%d", array[j]);
	fputc('-', wptr);
	fputc('>', wptr);
      }
    }
  }
  fputc('N', wptr);	
  fputc('U', wptr);
  fputc('L', wptr);
  fputc('L', wptr);
  fputc('\n', wptr);
  fclose(fptr);
  fclose(wptr);
}
void creat_huffman_file(char* filename, char* outputFile, lnode **tree){
  int arrayCh[256] = {0};
  FILE* fptr;
  int numChars;
  int i;
  char ch;
  int intChar;
  int numTree = 0;
  
  fptr = fopen(filename, "r");
  
  if(fptr == NULL){
    return ;
  }
  
  fseek(fptr, 0, SEEK_END);
  numChars = ftell(fptr);
  
  fseek(fptr, 0, SEEK_SET);
  
  for(i = 0; i < numChars; i++){
    ch = fgetc(fptr);
    intChar = (int)ch;
   
    arrayCh[intChar] = arrayCh[intChar] + 1; 
  }
  
  for (i = 0; i <= 255; i++){
    if(arrayCh[i] != 0){
      numTree++;
    }
  }
  //=============================================================================================
  lnode* head = NULL;

  for (i = 0; i <= 255; i++){
    if(arrayCh[i] != 0){
      tnode* n = malloc(sizeof(tnode));
      if (n == NULL) {
	return ;
      }
      n -> ch = i;
      n -> weight = arrayCh[i];
      n -> left = NULL;
      n -> right = NULL;
      PQ_enqueue(&head, n, int_cmp);      
    }
  }
  
  
  while(head -> next != NULL){
    tnode* newTnode = malloc(sizeof(tnode));\
    if (newTnode == NULL) {
      return;
    }
    lnode* poped;
    newTnode->left = head->ptr;
    newTnode->right = head->next->ptr;
    newTnode->weight = (newTnode->left->weight) +(newTnode->right->weight);
    PQ_enqueue(&head, newTnode, int_cmp);
    poped = stack_pop(&head);
    lnode_destroy(poped, destroy_fnf);
    poped = stack_pop(&head);
    lnode_destroy(poped, destroy_fnf);
  }
  
  char pathArray[256];
  FILE* wptr;
  wptr = fopen(outputFile, "w");    
  if(wptr == NULL){
    return ;
  }
  fseek(wptr, 0, SEEK_SET);
  encoding_fn(head->ptr, pathArray, 0, wptr);
  bst_destroy(head->ptr);
  lnode_destroy(head, destroy_fnf);
  fclose(wptr);
  fclose(fptr);

  return;
}
//======================================-----------------------------------------------------
void encoding_fn(tnode *tree, char path[], int index, FILE* fwptr)
{
   if (tree == NULL) {
      return;
   }
   
   if ((tree -> left == NULL) &&(tree->right == NULL))
   {
     fseek(fwptr, 0, SEEK_END);
     fputc(tree->ch, fwptr);
     fputc(':', fwptr);
     int i;
     for (i = 0; i < index; i++)
     {
       if(path[i] == '0' || path[i] == '1')
       {
	 fputc(path[i], fwptr);
       }
     }
     fputc('\n', fwptr);
     return;
   }
   
   path[index] = '0';
   encoding_fn(tree->left, path, index+1, fwptr);
   path[index] = '1';
   encoding_fn(tree->right, path, index+1, fwptr);
}

lnode *PQ_enqueue(lnode **pq, const void *new_object, 
                  int (*cmp_fn)(const void *, const void *))
{
  if (new_object == NULL) {
    return NULL;
  }
  lnode *new_node = (lnode *)malloc(sizeof(lnode));
  if (new_node == NULL) {
    return NULL;
  }
  new_node->ptr = (void*)new_object;
  new_node->next = NULL;
  if (new_node == NULL) {
    return NULL;
  }
  lnode dummy;
  dummy.next = *pq;
  lnode *prev = &dummy;
  lnode *curr = *pq;
  
  while (curr != NULL) {
    if (cmp_fn(curr->ptr, new_object) > 0) {
      break;
    } else {
      prev = curr;
      curr = curr->next;
    }
  }
  prev->next = new_node;
  new_node->next = curr;
  *pq = dummy.next;

  return new_node;
}

static int int_cmp(const void *p1, const void *p2)
{
  const tnode *ptr1 = p1;
  const tnode *ptr2 = p2;
  return  ((ptr1->weight) - (ptr2->weight));
}

lnode *stack_pop(lnode **stack)
{
  if (*stack == NULL) {
    return NULL;
  }
  lnode *ret_node = *stack; 
  *stack = ret_node->next;  
  ret_node->next = NULL;    
  return ret_node;
}

void preorder(tnode *root)
{
   if (root == NULL) {
      return;
   }
   
   preorder(root->left);
   printf("%c", root->ch);
   printf(":%d ", root->weight);

   preorder(root->right);
}

void printlnode(lnode *lnodePtr){
  if (lnodePtr == NULL) {
    return;
  }
  printf("%c:", lnodePtr->ptr->ch);
  printf("%d ", lnodePtr->ptr->weight);
  printlnode(lnodePtr->next);
}

void lnode_destroy(lnode *list, void (*destroy_fn)(void *))
{
  while (list != NULL) {
    lnode *tmp = list->next;
    destroy_fn(list->ptr);
    free(list);
    list = tmp;
  }
  return;
}

void destroy_fnf(void * varf)
{
	
	return;
}

void bst_destroy(tnode *root)
{
   if (root == NULL) {
      return;
   }
   bst_destroy(root->left);
   bst_destroy(root->right);
   free(root);
}
