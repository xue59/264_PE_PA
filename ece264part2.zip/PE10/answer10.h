
typedef struct _tnode {
  char ch; 
  int  weight;
  struct _tnode *left;
  struct _tnode *right;
} tnode;

typedef struct _lnode{
  tnode* ptr;
  struct _lnode *next;
}lnode;

void creat_count_file(char* filename, char* outputFile);
void creat_sort_file(char* filename, char* outputFile);
void creat_huffman_file(char* filename, char* outputFile, lnode **tree);

