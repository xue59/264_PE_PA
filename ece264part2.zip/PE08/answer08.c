#include <stdio.h>
#include <stdlib.h>
#include "answer08.h"

// if you want to declare and define new functions, do not name them
// with a prefix "__".  The instructors will be using functions with
// such names to test your individual functions.  You should not be 
// calling a function whose name has a prefix "__" because your program
// should compile without any functions from the instructors.
// you may put your additional functions here or at the end of this file



// allocate space from heap memory for the user-defined structure Maze, and
// allocate nrow x ncol maze and store the address in the structure (in 
// maze_array)
// also assign nrow and ncol fields in the structure accordingly
// if allocation fails, return NULL
// if allocation fails, you are also responsible for freeing the memory
// allocated in this function before the failure
// may assume that nrow and ncol are > 0

Maze *Allocate_maze_space(int nrow, int ncol)
{
    // need when allocation is failed
    Maze *maze =  malloc(sizeof(Maze));
      if(maze == NULL){
	free(maze);
	return NULL;
    }

    maze -> ncol = ncol;
    maze -> nrow = nrow;
    maze -> maze_array = malloc(sizeof(char*) * nrow);
    if(maze -> maze_array == NULL){
      free(maze -> maze_array);
      free(maze);
      return NULL;
    }

    int i = 0;
    
    for(i = 0; i < nrow; i++){
        maze -> maze_array[i] = malloc(sizeof(char) * ncol);
	if(maze -> maze_array[i] == NULL){
	  
	  int j = 0;
	  
	  for(j = 0; j < i; j++){
	    free(maze->maze_array[j]);
	  }
	  free(maze->maze_array);
	  free(maze);
	  return NULL;
	}
    }
    return maze;
}

// free the memory used for the maze
// you may assume that maze is not NULL, and all memory addresses are valid

void Deallocate_maze_space(Maze *maze)
{
    int i;
    
    for(i = 0; i < maze->nrow; i++){
        free(maze->maze_array[i]);
    }
    free(maze->maze_array);
    free(maze);
    
    return;
}

/* Read maze in a multi-line file and store the necessary information */
/* into a 2D array of characters.  The address of the 2D array and the */
/* dimensions of the 2D array should be stored in a Maze structure allocated */
/* from the heap memory */
/* if the allocation fails, should return NULL */

Maze *Read_maze_from_2Dfile(FILE *fptr)
{
    Maze *fmaze;
    int nrow;
    int ncol;
    int row = 0;
    int col = 0;
    char ch;
    long int i;
    long int j;
   

    fseek(fptr, 0, SEEK_SET);
    
    for (col = 0; ch != '\n'; col++)
    {
        ch = fgetc(fptr);
    }
    
    fseek(fptr, 0, SEEK_END);
    j = ftell(fptr);
    
    fseek(fptr, 0, SEEK_SET);
    for (i = 0; i < j; i++)
    {
        ch = fgetc(fptr);
        if(ch == '\n')
        {
            row++;
        }
    }
    
    nrow = row;
    ncol = col - 1;
    
    fmaze = Allocate_maze_space(nrow, ncol);
    if(fmaze ==NULL){
      return NULL;
    }
    // starting assign into each structure

    fseek(fptr, 0, SEEK_SET);
    ch = '0';
    for(i = 0; i < fmaze -> nrow; i++){
      for (j = 0; j < fmaze -> ncol+1; j++){
	ch = fgetc(fptr);
	if(ch != '\n'){
	  fmaze -> maze_array[i][j] = ch;	  
	}
      }
    }
    return fmaze;
}

/* Write the maze into a multi-line file */
/* the maze has to stay intact */

int Write_maze_to_2Dfile(char *filename, const Maze *maze)
{
  int i;
  int j;
  char ch;
  FILE *wptr;

  wptr = fopen(filename,"w");
  if(wptr == NULL){
    return -1;
  }
  
  fseek(wptr, 0, SEEK_SET);
  
  for(i = 0; i < maze -> nrow; i++){
    for (j = 0; j < maze -> ncol; j++){
      ch = maze -> maze_array[i][j];
      fputc(ch, wptr);
    }
    fputc('\n', wptr);
  }
  
  fclose(wptr);
  return 0;
}

/* Expand the maze from nrow x ncol to (2nrow - 1) x ncol */
/* the top half of the maze is the same as the original maze */
/* the bottom half of the maze is a reflection of the original maze */
/* You have to allocate space for a new maze */
/* the nrow and ncol fields of the new maze have to be assigned accordingly */
/* if you can't expand the maze because of memory issue, NULL should be */
/* returned */
/* the original maze has to stay intact */

Maze *Expand_maze_row(const Maze *maze)
{
  int ncolEx = maze -> ncol;
  int nrowEx = (maze -> nrow) * 2 - 1;
  Maze *mazeEx; 
  int i;
  int j;
  int cpyR = (maze -> nrow) - 2;

  mazeEx = Allocate_maze_space(nrowEx, ncolEx);
  if(mazeEx == NULL){
    return NULL;
  }
  
  // Staring expand row into structure
  for(i = 0; i < maze -> nrow; i++){
    for(j = 0; j < maze -> ncol; j++){
      (mazeEx -> maze_array[i][j]) = (maze -> maze_array[i][j]);
    }
  }
  
  for(i = maze -> nrow; i < nrowEx; i++){
    for(j = 0; j < ncolEx; j++){
      (mazeEx -> maze_array[i][j])= (maze -> maze_array[cpyR][j]);
    }
    cpyR--;
  }
  return mazeEx;
}

/* Expand the maze from nrow x ncol to nrow x 2ncol - 1 */
/* the left half of the maze is the same as the original maze */
/* the right half of the maze is a reflection of the original maze */
/* moreover, you have to create an opening between the left and right halves */
/* the opening should be at the middle row of the maze */
/* the opening must also be accessible from one of the paths in the */
/* new maze */
/* to do that, you have to convert some locations that are WALL to PATH */
/* starting from the new opening to the left and to the right until you reach */
/* a location that is adjacent to a location that is PATH */
/* You have to allocate space for a new maze */
/* the nrow and ncol fields of the new maze have to be assigned accordingly */
/* if you can't expand the maze because of memory issue, NULL should be */
/* returned */
/* the original maze has to stay intact */

Maze *Expand_maze_column(const Maze *maze)
{
  int ncolEx = (maze -> ncol) * 2 - 1;
  int nrowEx = maze -> nrow;
  int midCol = (maze -> ncol) - 1;
  int midRow = ((maze -> nrow) - 1) / 2;
  int upRow = midRow - 1;
  int lowRow = midRow + 1;
  Maze *mazeEx; 
  int i;
  int j;
  int cpyC;;
  

  mazeEx = Allocate_maze_space(nrowEx, ncolEx);
  if(mazeEx == NULL){
    return NULL;
  }

  // Staring expand row into structure
  for(i = 0; i < maze -> nrow; i++){
    for(j = 0; j < maze -> ncol; j++){
      (mazeEx -> maze_array[i][j]) = (maze -> maze_array[i][j]);
    }
  }

  cpyC = (maze -> ncol) - 2;
  for(i = 0; i < nrowEx; i++){
    for(j = maze -> ncol; j < ncolEx; j++){
      (mazeEx -> maze_array[i][j])= (maze -> maze_array[i][cpyC]);
      cpyC--;
    }
    cpyC = (maze -> ncol) - 2;
  }
  
  // Checking for the opening path in the middle
  // left half
  mazeEx -> maze_array[midRow][midCol] = ' ';
  mazeEx -> maze_array[midRow][midCol + 1] = ' ';
  mazeEx -> maze_array[midRow][midCol - 1] = ' ';
  
  i = maze -> ncol - 1;
  while (mazeEx -> maze_array[upRow][i] == 'X' && mazeEx -> maze_array[lowRow][i] == 'X'){
    mazeEx -> maze_array[midRow][i] = ' ';
    i--;
  }
  
  // right half
  i = maze -> ncol;
  while (mazeEx -> maze_array[upRow][i] == 'X' && mazeEx -> maze_array[lowRow][i] == 'X'){
    mazeEx -> maze_array[midRow][i] = ' ';
    i++;
  }
  
  return mazeEx;
}

// if you want to declare and define new functions, put them here
// or at the beginning of the file

