//  pe08.c
#include <stdio.h>
#include <stdlib.h>
#include "answer08.h"


int main(int argc, char ** argv)
{
    FILE *ptr;
    Maze *mazeM;
    int i;
    int j;
    Maze *mazeExpandRow;
    Maze *mazeExpandCol;

    ptr = fopen(argv[1], "r+");
    mazeM = Read_maze_from_2Dfile(ptr);
    printf("\nRow: %d Col: %d \n", mazeM -> nrow, mazeM -> ncol);
    
    for(i = 0; i < mazeM -> nrow; i++){
      for (j = 0; j < mazeM -> ncol; j++){
	printf("%c", mazeM -> maze_array[i][j]);
      }
      printf("\n");
    }
    printf("\n\n");
    // function 444444444444444444 testing
    Write_maze_to_2Dfile(argv[2], mazeM);
    
    // function 5555555555555555555testing
     mazeExpandRow = Expand_maze_row(mazeM);
    
    Write_maze_to_2Dfile(argv[3],mazeExpandRow);
    for(i = 0; i < mazeExpandRow -> nrow; i++){
      for (j = 0; j < mazeExpandRow -> ncol; j++){
	printf("%c", mazeExpandRow -> maze_array[i][j]);
      }
      printf("\n");
    }
    
    printf("\n");
    printf("\n");
    
    // function 66666666666666666test
    mazeExpandCol = Expand_maze_column(mazeM);
    Write_maze_to_2Dfile(argv[4],mazeExpandCol);
    for(i = 0; i < mazeExpandCol -> nrow; i++){
      for (j = 0; j < mazeExpandCol -> ncol; j++){
	printf("%c", mazeExpandCol -> maze_array[i][j]);
      }
      printf("\n");
    }
        
   

    Deallocate_maze_space(mazeExpandCol);
    Deallocate_maze_space(mazeM);
    Deallocate_maze_space(mazeExpandRow);
    fclose(ptr);
    return EXIT_SUCCESS;
}
