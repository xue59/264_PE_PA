#include "answer05.h"
#include <strings.h>
#include <stdio.h>

// You do not have to use malloc in this exercise. If you use 
// malloc, please remember to free the memory.

// Hint: create a helper function for recursion
/*
  The helper function has the following flow:

  1. check the terminating conditions
     This occurs when
    a. the upper deck has no card or
	b. the lower deck has no card

     When either of the terminating conditions is met, put the
     remaining cards in the other deck to the result.  print the
     result by calling printDeck (implemented in utility.c)

     This should be the only place where printDeck is called

  2. If the terminating conditions are not met, this helper 
     function considers the two possible ways to create the 
     new deck:

        a. pick one card from the upper deck and add it to the
           new deck
            
           call the helper function again (recursion) but the
	   upper deck has one fewer card now; the lower deck
           is unchanged

        b. pick one card from the lower deck and add it to the
           new deck
            
           call the helper function again (recursion) but the
	   lower deck has one fewer card now; the upper deck
           is unchanged

   To make this helper function work, the helper function needs the
   following information as arguments:
   
   Obviously, this helper function needs information about the upper
   and the lower decks. It also needs to know how many cards are left
   in the upper and the lower decks because this information is used
   for the terminating conditions.
   
   The helper function may need additional arguments based on your
   design.

 */
void helperF(CardDeck upperdeck, CardDeck lowerdeck, CardDeck newdeck, int size_new, int size_upper, int size_lower)
{
    if(size_upper == upperdeck.size)
    {
        bcopy(& lowerdeck.cards[size_lower], & newdeck.cards[size_new], lowerdeck.size * sizeof(char));
        printDeck(newdeck);
        printf("\n");
        return;
    }
    else if (size_lower == lowerdeck.size)
    {
        bcopy(& upperdeck.cards[size_upper], & newdeck.cards[size_new], upperdeck.size * sizeof(char));
        printDeck(newdeck);
        printf("\n");
        return;
    }
    
    
    
/*    newdeck.cards[size_new] = lowerdeck.cards[size_lower];
    helperF(upperdeck, lowerdeck, newdeck, size_new + 1 , size_upper, size_lower + 1);
    
    size_new = size_lower + size_upper;

    newdeck.cards[size_new] = upperdeck.cards[size_upper];
    //    size_new++;
    //size_upper++;
    helperF(upperdeck, lowerdeck, newdeck, size_new+1, size_upper+1, size_lower);
*/

 	newdeck.cards[size_new] = upperdeck.cards[size_upper];
 	helperF(upperdeck, lowerdeck, newdeck, size_new + 1, size_upper + 1, size_lower);
      
 	size_new = size_lower + size_upper;
      
 	newdeck.cards[size_new] = lowerdeck.cards[size_lower];
 	helperF(upperdeck, lowerdeck, newdeck, size_new + 1, size_upper, size_lower + 1);
}

void interleave(CardDeck upperdeck, 
		CardDeck lowerdeck)
{
  // create a new deck storing the result
  // this new deck's size should be the sum of the
  // sizes of upperdeck and lowerdeck
    CardDeck  newdeck;
    newdeck.size = (upperdeck.size + lowerdeck.size);
    int size_new;
    int size_upper;
    int size_lower;
    
    size_new = 0;
    size_upper = 0;
    size_lower = 0;
    helperF(upperdeck,lowerdeck, newdeck, size_new, size_upper, size_lower);

 
  // call the helper function with appropriate arguments




  
}

