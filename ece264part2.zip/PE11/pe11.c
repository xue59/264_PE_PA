#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int main(int argc, char*argv[])
{
  FILE *fptr;
  FILE *wptr;
  BMP_Image* bmpptr;
  BMP_Image* bmpRE;
  int i;
  
  fptr = fopen(argv[argc - 2], "r");
  if(fptr == NULL){
    fprintf(stderr, "Can't open input file\n");
    return EXIT_FAILURE;
  }

  wptr = fopen(argv[argc - 1], "w");
  if(wptr == NULL){
    fprintf(stderr, "Can't open file for output\n");
    fclose(fptr);
    return EXIT_FAILURE;
  }
  
  // read image into structure
  bmpptr = Read_BMP_Image(fptr);
  if(bmpptr == NULL){
    fprintf(stderr, "Error reading input file\n");
    fclose(wptr);
    return EXIT_FAILURE;
  }
  fclose(fptr);
  
  bmpRE = bmpptr;
  // make the reflected image
  
  if (argc == 3){
    Write_BMP_Image(wptr, bmpRE);
    fclose(wptr);
    return EXIT_FAILURE;
  }

  else if (argc >= 4)
  {
    for(i = 1; i <= (argc - 3); i++){
      if(argv[i][0] == '-' && argv[i][1] == 'v'){
	bmpRE = Reflect_BMP_Image(bmpRE, 0,1);
      }else if(argv[i][0] == '-' && argv[i][1] == 'h'){
	bmpRE = Reflect_BMP_Image(bmpRE, 1,0);
      }
      else{
	fprintf(stderr, "Invalid option.  -h or -v expected\n");
	Free_BMP_Image(bmpptr);
	fclose(wptr);
	return EXIT_FAILURE;
      }
    }

    //write reflected image to file
    Write_BMP_Image(wptr, bmpRE);  
    
    //free memory and close file 
    fclose(wptr);
    return EXIT_SUCCESS;
  }
  Free_BMP_Image(bmpptr);
  Free_BMP_Image(bmpRE);
  fclose(wptr);
  return EXIT_FAILURE;
  
}
