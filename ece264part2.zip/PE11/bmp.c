#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "bmp.h"

/* check whether a header is valid
 * assume that header has been read from fptr
 * the position of the indicator of fptr is not certain
 * could be at the beginning of the file, end of the file or 
 * anywhere in the file
 * note that the check is only for this exercise/assignment
 * in general, the format is more complicated
 */

int Is_BMP_Header_Valid(BMP_Header* header, FILE *fptr) {
  // Make sure this is a BMP file
  if (header->type != 0x4d42) {
     return FALSE;
  }
  // skip the two unused reserved fields

  // check the offset from beginning of file to image data
  // essentially the size of the BMP header
  // BMP_HEADER_SIZE for this exercise/assignment
  if (header->offset != BMP_HEADER_SIZE) {
     return FALSE;
  }
      
  // check the DIB header size == DIB_HEADER_SIZE
  // For this exercise/assignment
  if (header->DIB_header_size != DIB_HEADER_SIZE) {
     return FALSE;
  }

  // Make sure there is only one image plane
  if (header->planes != 1) {
    return FALSE;
  }
  // Make sure there is no compression
  if (header->compression != 0) {
    return FALSE;
  }

  // skip the test for xresolution, yresolution

  // ncolours and importantcolours should be 0
  if (header->ncolours != 0) {
    return FALSE;
  }
  if (header->importantcolours != 0) {
    return FALSE;
  }
  
  // Make sure we are getting 24 bits per pixel
  // or 16 bits per pixel
  // only for this assignment
  if (header->bits != 24 && header->bits != 16) {
    return FALSE;
  }

  // fill in extra to check for file size, image size
  // based on bits, width, and height
  
  // for image size 
  if (header->bits == 24){
    int numPix = header->width;
    int rowData = numPix*3;
    if (rowData%4 != 0){
      rowData = (4-((numPix*3)%4) + numPix*3); 
    }
    
    if(header->imagesize != rowData * header->height){
      return FALSE;
    }
  }else if(header->bits == 16){
    int numPix = header->width;
    int rowData = numPix*2;

    if (rowData%4 != 0){
      rowData = (4-((numPix*3)%4) + numPix*3); 
    }
    
    if(header->imagesize != rowData * header->height){
      return FALSE;
    }
  }
  
  //for file size
  fseek(fptr, 0, SEEK_SET);
  int sz;
  fseek(fptr, 0, SEEK_END);
  sz = ftell(fptr);
  if(header->size != sz){
    return FALSE;
  }

  return TRUE;
}

/* The input argument is the source file pointer. 
 * The function returns an address to a dynamically allocated BMP_Image only 
 * if the file * contains a valid image file 
 * Otherwise, return NULL
 * If the function cannot get the necessary memory to store the image, also 
 * return NULL
 * Any error messages should be printed to stderr
 */
BMP_Image *Read_BMP_Image(FILE* fptr) {

  // go to the beginning of the file
  fseek(fptr,0, SEEK_SET);
  BMP_Image *bmp_image = NULL;

  //Allocate memory for BMP_Image*;
  bmp_image = malloc(sizeof(BMP_Image));
  if(bmp_image == NULL){
    fprintf(stderr, "Error allocating memory\n");
    return NULL;
  }

  //Read the first 54 bytes of the source into the header
  fread(&bmp_image->header, 1, 54, fptr);

  // if read successful, check validity of header
  if((Is_BMP_Header_Valid(&bmp_image->header, fptr)) != 1){
    fprintf(stderr, "Can't open file for output\n");
    return FALSE;   
  }
  
  // Allocate memory for image data
  bmp_image -> data = malloc(bmp_image->header.imagesize);
  if(bmp_image -> data == NULL){
    return NULL;
  }
  
  // read in the image data
  fseek(fptr, 54,SEEK_SET);
  fread(bmp_image->data, 1, bmp_image->header.imagesize, fptr);

  return bmp_image;
}

/* The input arguments are the destination file pointer, BMP_Image *image.
 * The function write the header and image data into the destination file.
 * return TRUE if write is successful
 * FALSE otherwise
 */
int Write_BMP_Image(FILE* fptr, BMP_Image* image) 
{
  // go to the beginning of the file
  fseek(fptr, 0, SEEK_SET);
  
  // write header
  fwrite(&image->header, sizeof(unsigned char), 54, fptr);
  
  // write image data
  fseek(fptr, 0, SEEK_END);
  fwrite(image->data, sizeof(unsigned char), image->header.imagesize, fptr);
  
  Free_BMP_Image(image);
  return TRUE;
}

/* The input argument is the BMP_Image pointer. The function frees memory of 
 * the BMP_Image.
 */
void Free_BMP_Image(BMP_Image* image) {
  free(image->data);
  free(image);
}

// Given a BMP_Image, create a new image that is a reflection 
// of the given image
// It could be a horizontal reflection (with the vertical mirror 
// being placed at the center of the image) 
// It could be a vertical reflection (with the horizontal mirror
// being placed at the center of the image)
// It could be a horizontal reflection followed by a vertical
// reflection (or equivalently, a vertical reflection followed by
// horizontal reflection).
// hrefl == 1 implies that a horizontal reflection should take place
// hrefl == 0 implies that a horizontal reflection should not take place
// vrefl == 1 implies that a vertical reflection should take place
// vrefl == 0 implies that a vertical reflection should not take place

BMP_Image *Reflect_BMP_Image(BMP_Image *image, int hrefl, int vrefl)
{
   // create a new image reflected from the given image
   BMP_Image *t_image = NULL;

  //Allocate memory for BMP_Image*;
   t_image = malloc(sizeof(BMP_Image));
   if(t_image == NULL){
     fprintf(stderr, "Error allocating memory\n");
     return NULL;
   }
  
  // assign header to new header 
  t_image->header = image->header;

  // Allocate memory for image data
  t_image -> data = malloc(t_image->header.imagesize);
  if(t_image -> data == NULL){
    fprintf(stderr, "Error allocating memory\n");
    return NULL;
  }
  
  int height = image->header.height;
  int width = image->header.width;
  int bytesRow = image->header.imagesize / image->header.height;
  int dataPix = image->header.bits / 8;
  int numPadding = bytesRow - (width * dataPix);
  int i;
  int j;
  int t_new;
  int i_old;
  
  if (numPadding != 0){
    for(i = 0; i < height; i++){
      t_new = bytesRow - numPadding;
      i_old = bytesRow - numPadding;
      memcpy(&(t_image->data[t_new]), &(image->data[i_old]),numPadding);
    }
  }

  if(hrefl == 1){
    for(i = 0; i < height; i++){
      for (j = 0; j < width; j++){
	t_new = i*bytesRow + j*dataPix;
	i_old = (i+1)*bytesRow - j*dataPix - dataPix - numPadding;
	memcpy(&(t_image->data[t_new]), &(image->data[i_old]),dataPix);
      }
    }
  }
  else if(vrefl == 1 ){
    for(i = 0; i < height; i++){
      t_new = i * bytesRow;
      i_old = height * bytesRow - i*bytesRow - bytesRow;
      memcpy(&(t_image->data[t_new]), &(image->data[i_old]),bytesRow);
    }
  }
  
  Free_BMP_Image(image);
  return t_image;
}
