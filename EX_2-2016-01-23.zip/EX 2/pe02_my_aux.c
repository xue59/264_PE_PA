#include <stdio.h>
#include <stdlib.h>
#include "pe02_aux.h"

// This is the function needed to be integrated for testing propurse. 
double function_to_be_integrated(double x)
{
    double y;

    y = -(pow(x , 2)) + 4;
    
    
    return y;
}


