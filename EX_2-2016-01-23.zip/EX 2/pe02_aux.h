#ifndef PE02_AUX_H
#define PE02_AUX_H 

#include <math.h>

// unknown function
//
double function_to_be_integrated(double x);

#endif
